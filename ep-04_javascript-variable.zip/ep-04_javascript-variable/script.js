console.log(firstName)

var firstName = 'Khushbu'
let lastName = 'Singh'
let age = 15
let खुशहै = true
firstName = 100
var a

const hoursInDay = 24


let userIntro = 
    'Hi, my name is ' 
    + firstName + ' ' 
    + lastName + '. I am ' + age + ' ' + 'years old.'